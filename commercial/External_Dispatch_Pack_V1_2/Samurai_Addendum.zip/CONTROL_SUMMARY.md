# Public Signal Pack Control Summary

## Core Messaging

HPP is presented here as a local-first governance architecture.

This public signal pack is limited to:

- read-only / simulation-only posture
- state classification
- reflex policy gating
- operator consent
- evidence replay
- buyer-safe routing

## Explicit Boundaries

- no live robot motion
- no autonomous robotics claim
- no camera capture claim
- no network authority claim
- no AGI or sentience claim
- no HQA / quantum claim

## Use

Use these posts to point serious readers toward a bounded technical review path. Do not paste internal file paths, hashes, or repo details into public comments.
