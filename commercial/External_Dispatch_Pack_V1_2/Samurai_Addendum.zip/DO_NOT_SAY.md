# Do Not Say

Avoid these in public copy:

- guarantee
- unhackable
- impossible to bypass
- definitive proof
- liability-free
- production-ready robotics
- live robot control
- autonomous robot
- AGI
- sentience
- consciousness
- HQA or quantum claims
- private local paths
- raw hashes unless specifically needed under MNDA

Use instead:

- tested scenario
- bounded evidence
- smoke-tested copy
- read-only / simulation-only
- governance layer
- replayable audit artifacts
- not live robotics control
